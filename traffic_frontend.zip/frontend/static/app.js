/**
 * AI Smart Traffic Signal System — Frontend
 * Author: Kalivarapu Charan Sai
 */

const API_BASE = "http://localhost:8000";
const WS_URL   = "ws://localhost:8000/ws/traffic";

// ── State ─────────────────────────────────────────────
let state = {};
let selectedId = null;
let ws = null;
let reconnectTimer = null;
let densityHistory = [];
let currentFilter = "all";

const MAX_HISTORY = 20;
const DIRECTIONS = ["North", "South", "East", "West"];

// ── Init ─────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  updateClock();
  setInterval(updateClock, 1000);
  connectWebSocket();
  fetchAnalytics();
  fetchEmergencyAlerts();
  setInterval(fetchAnalytics, 8000);
  setInterval(fetchEmergencyAlerts, 10000);
});

// ── Clock ─────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  document.getElementById("timeDisplay").textContent =
    now.toLocaleTimeString("en-IN", { hour12: false });
}

// ── WebSocket ─────────────────────────────────────────
function connectWebSocket() {
  if (ws) ws.close();
  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    setWsStatus(true);
    addLog("WebSocket connected to traffic engine");
    clearInterval(reconnectTimer);
  };

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    handleWSMessage(msg);
  };

  ws.onerror = () => {
    setWsStatus(false);
    addLog("WebSocket error — retrying...");
  };

  ws.onclose = () => {
    setWsStatus(false);
    addLog("WebSocket disconnected — reconnecting in 4s");
    reconnectTimer = setTimeout(connectWebSocket, 4000);
  };
}

function setWsStatus(connected) {
  const dot   = document.querySelector(".ws-dot");
  const label = document.getElementById("wsLabel");
  dot.className   = "ws-dot " + (connected ? "connected" : "disconnected");
  label.textContent = connected ? "Live" : "Disconnected";
}

function handleWSMessage(msg) {
  if (msg.type === "initial_state" || msg.type === "state_update") {
    state = msg.data;
    renderIntersectionList();
    if (selectedId && state[selectedId]) {
      renderSignalView(selectedId);
    }
    // Track density for chart
    const avg = avgDensity();
    densityHistory.push({ t: new Date(), v: avg });
    if (densityHistory.length > MAX_HISTORY) densityHistory.shift();
    drawDensityChart();
  }

  if (msg.type === "emergency_alert") {
    const a = msg.data;
    showEmergencyBanner(
      `🚨 ${a.vehicle_type} detected at ${a.intersection_name} → ${a.direction} (${Math.round(a.confidence * 100)}% confidence)`
    );
    addLog(`EMERGENCY: ${a.vehicle_type} at ${a.intersection_name}`);
    fetchEmergencyAlerts();
  }

  if (msg.type === "emergency_cleared") {
    addLog(`Emergency cleared at intersection ${msg.data.intersection_id}`);
  }
}

// ── Render Intersection List ──────────────────────────
function renderIntersectionList() {
  const list = document.getElementById("intersectionList");
  const tpl  = document.getElementById("intersectionCardTpl");
  list.innerHTML = "";

  const ids = Object.keys(state).filter(id =>
    currentFilter === "all" || state[id].mode === currentFilter
  );

  if (!ids.length) {
    list.innerHTML = `<p class="empty-state">No intersections match filter</p>`;
    return;
  }

  ids.forEach(id => {
    const s = state[id];
    const clone = tpl.content.cloneNode(true);
    const card  = clone.querySelector(".int-card");

    card.dataset.id = id;
    card.querySelector(".int-name").textContent = s.name;
    card.querySelector(".int-id").textContent   = id;

    const pill = card.querySelector(".int-mode-pill");
    pill.textContent  = s.mode;
    pill.className    = `int-mode-pill pill-${s.mode}`;

    if (s.mode === "EMERGENCY") card.classList.add("emergency-card");
    if (id === selectedId) card.classList.add("selected");

    // Mini lane rows
    const lanesEl = card.querySelector(".int-lanes");
    DIRECTIONS.forEach(d => {
      const lane = s.lanes[d];
      const div  = document.createElement("div");
      div.className = "lane-mini";
      div.innerHTML = `
        <span class="lane-mini-label">${d.substring(0,1)}</span>
        <div class="lane-mini-info">
          <span class="lane-dot ${lane.signal}"></span>
          <span class="lane-count">${lane.vehicle_count}v</span>
        </div>
      `;
      lanesEl.appendChild(div);
    });

    // Footer
    const updated = new Date(s.last_updated);
    card.querySelector(".int-last-update").textContent =
      "Updated " + updated.toLocaleTimeString("en-IN", { hour12: false });

    card.querySelector(".int-view-btn").onclick = (e) => {
      e.stopPropagation();
      selectIntersection(id);
    };
    card.onclick = () => selectIntersection(id);

    list.appendChild(clone);
  });
}

// ── Select Intersection ───────────────────────────────
function selectIntersection(id) {
  selectedId = id;
  document.querySelectorAll(".int-card").forEach(c =>
    c.classList.toggle("selected", c.dataset.id === id)
  );
  renderSignalView(id);
}

function renderSignalView(id) {
  const s = state[id];
  if (!s) return;

  document.getElementById("selectedName").textContent = s.name;

  const badge = document.getElementById("modeBadge");
  badge.textContent = s.mode;
  badge.className   = `mode-badge pill-${s.mode}`;

  const grid = document.getElementById("signalGrid");
  grid.innerHTML = "";

  DIRECTIONS.forEach(d => {
    const lane  = s.lanes[d];
    const sigClass = lane.signal;
    const densityPct = Math.round(lane.density * 100);
    const densityClass = lane.density < 0.4 ? "low" : lane.density < 0.7 ? "medium" : "high";
    const isEmergency = s.emergency_direction === d;

    const card = document.createElement("div");
    card.className = `signal-lane-card ${sigClass}`;
    card.innerHTML = `
      <div class="slc-header">
        <span class="slc-direction">${d}${isEmergency ? " 🚨" : ""}</span>
        <div class="signal-light ${sigClass}">${sigClass.substring(0,1)}</div>
      </div>
      <div class="slc-row">
        <span class="slc-key">Vehicles</span>
        <span class="slc-val">${lane.vehicle_count}</span>
      </div>
      <div class="slc-row">
        <span class="slc-key">Wait</span>
        <span class="slc-val">${lane.wait_time}s</span>
      </div>
      <div class="slc-row">
        <span class="slc-key">Queue</span>
        <span class="slc-val">${lane.queue_length}</span>
      </div>
      <div class="slc-row">
        <span class="slc-key">Density</span>
        <span class="slc-val">${densityPct}%</span>
      </div>
      <div class="density-bar">
        <div class="density-fill ${densityClass}" style="width:${densityPct}%"></div>
      </div>
      <div class="green-timer">Green allocation: ${lane.green_duration}s</div>
    `;
    grid.appendChild(card);
  });

  // Show controls
  const controls = document.getElementById("signalControls");
  controls.style.display = "block";

  // Sync mode buttons
  document.querySelectorAll(".mode-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.mode === s.mode);
  });

  const overrideRow = document.getElementById("overrideRow");
  overrideRow.style.display = s.mode === "MANUAL" ? "flex" : "none";
}

// ── Mode Control ──────────────────────────────────────
async function setMode(mode, btn) {
  if (!selectedId) return;
  document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");

  document.getElementById("overrideRow").style.display =
    mode === "MANUAL" ? "flex" : "none";

  try {
    await fetch(`${API_BASE}/api/intersections/${selectedId}/mode`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode })
    });
    addLog(`Mode set to ${mode} at ${selectedId}`);
  } catch (e) {
    addLog(`Failed to set mode: ${e.message}`);
  }
}

async function overrideSignal(signal) {
  if (!selectedId) return;
  const direction = document.getElementById("overrideDir").value;
  try {
    await fetch(`${API_BASE}/api/intersections/${selectedId}/signal`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ direction, signal })
    });
    addLog(`Manual override: ${direction} → ${signal} at ${selectedId}`);
  } catch (e) {
    addLog(`Override failed: ${e.message}`);
  }
}

// ── Filter ────────────────────────────────────────────
function filterMode(mode, btn) {
  currentFilter = mode;
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  btn.classList.add("active");
  renderIntersectionList();
}

// ── Analytics ─────────────────────────────────────────
async function fetchAnalytics() {
  try {
    const res  = await fetch(`${API_BASE}/api/analytics/summary`);
    const data = await res.json();
    document.getElementById("statVehicles").textContent   = data.total_vehicles_detected;
    document.getElementById("statWait").textContent       = data.avg_wait_time_seconds;
    document.getElementById("statDensity").textContent    = (data.avg_density * 100).toFixed(0) + "%";
    document.getElementById("statCongestedVal").textContent = data.congested_lanes;

    const congCard = document.getElementById("statCongested");
    congCard.style.borderColor = data.congested_lanes > 4
      ? "rgba(255,77,77,0.6)" : "var(--border)";
  } catch {}
}

// ── Emergency Alerts ──────────────────────────────────
async function fetchEmergencyAlerts() {
  try {
    const res  = await fetch(`${API_BASE}/api/emergency-alerts`);
    const data = await res.json();
    const alerts = data.alerts.slice(0, 10);

    document.getElementById("alertCount").textContent = alerts.length;

    const list = document.getElementById("alertList");
    if (!alerts.length) {
      list.innerHTML = `<p class="empty-state">No active alerts</p>`;
      return;
    }
    list.innerHTML = alerts.map(a => `
      <div class="alert-item">
        <span class="alert-icon">🚑</span>
        <div class="alert-body">
          <div class="alert-title">${a.vehicle_type} — ${a.direction}</div>
          <div class="alert-detail">${a.intersection_name} · ${new Date(a.timestamp).toLocaleTimeString("en-IN")}</div>
        </div>
      </div>
    `).join("");
  } catch {}
}

// ── Banner ────────────────────────────────────────────
function showEmergencyBanner(msg) {
  const banner = document.getElementById("emergencyBanner");
  document.getElementById("emergencyText").textContent = msg;
  banner.classList.remove("hidden");
  setTimeout(() => banner.classList.add("hidden"), 15000);
}

function dismissBanner() {
  document.getElementById("emergencyBanner").classList.add("hidden");
}

// ── Log ───────────────────────────────────────────────
function addLog(msg) {
  const list = document.getElementById("logList");
  const now  = new Date().toLocaleTimeString("en-IN", { hour12: false });
  const entry = document.createElement("div");
  entry.className = "log-entry";
  entry.innerHTML = `<span class="log-time">${now}</span><span class="log-msg">${msg}</span>`;
  list.prepend(entry);
  // Keep max 60 entries
  while (list.children.length > 60) list.removeChild(list.lastChild);
}

// ── Density Chart (canvas) ────────────────────────────
function avgDensity() {
  if (!Object.keys(state).length) return 0;
  let total = 0, count = 0;
  for (const id in state) {
    for (const d of DIRECTIONS) {
      total += state[id].lanes[d].density;
      count++;
    }
  }
  return count ? total / count : 0;
}

function drawDensityChart() {
  const canvas = document.getElementById("densityChart");
  if (!canvas) return;
  const ctx    = canvas.getContext("2d");
  const W = canvas.clientWidth || 260;
  const H = 120;
  canvas.width  = W;
  canvas.height = H;

  ctx.clearRect(0, 0, W, H);

  if (densityHistory.length < 2) return;

  const pts = densityHistory;
  const max = 1.0;

  // Grid lines
  ctx.strokeStyle = "#1E2D40";
  ctx.lineWidth   = 1;
  [0.25, 0.5, 0.75].forEach(v => {
    const y = H - v * H;
    ctx.beginPath();
    ctx.moveTo(0, y); ctx.lineTo(W, y);
    ctx.stroke();
  });

  // Gradient fill
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0,   "rgba(0,212,170,0.4)");
  grad.addColorStop(1,   "rgba(0,212,170,0)");

  ctx.beginPath();
  pts.forEach((p, i) => {
    const x = (i / (MAX_HISTORY - 1)) * W;
    const y = H - (p.v / max) * H;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  // Close fill
  ctx.lineTo(W, H); ctx.lineTo(0, H);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  pts.forEach((p, i) => {
    const x = (i / (MAX_HISTORY - 1)) * W;
    const y = H - (p.v / max) * H;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.strokeStyle = "#00D4AA";
  ctx.lineWidth   = 2;
  ctx.stroke();

  // Threshold line 70%
  ctx.beginPath();
  ctx.moveTo(0, H * 0.3); ctx.lineTo(W, H * 0.3);
  ctx.strokeStyle = "rgba(255,77,77,0.4)";
  ctx.lineWidth   = 1;
  ctx.setLineDash([4, 4]);
  ctx.stroke();
  ctx.setLineDash([]);

  // Label
  ctx.fillStyle   = "#64748B";
  ctx.font        = "10px JetBrains Mono, monospace";
  ctx.fillText("70%", 4, H * 0.3 - 4);
}
