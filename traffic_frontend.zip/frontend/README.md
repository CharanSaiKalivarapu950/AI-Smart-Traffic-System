# AI Smart Traffic Signal System — Frontend

## How to Run

No build step needed. Open directly in browser:

```bash
# Option 1: Python simple server (recommended)
cd frontend
python -m http.server 3000
# Then open http://localhost:3000

# Option 2: VS Code Live Server
# Right-click index.html → Open with Live Server

# Option 3: Node http-server
npx http-server . -p 3000
```

> ⚠️ Make sure the backend is running at http://localhost:8000 first.

## Features

| Feature | Description |
|---------|-------------|
| Real-time Dashboard | WebSocket feed from backend, updates every 5s |
| Signal Visualizer | Live N/S/E/W signal states with glow indicators |
| Density Bar | Per-lane traffic density with color thresholds |
| Emergency Banner | Auto-pops with vehicle type, direction, confidence |
| Mode Control | Switch AI ↔ Manual, with manual signal override |
| Density Chart | Rolling canvas chart of average system density |
| System Log | Timestamped event feed |

## File Structure

```
frontend/
├── index.html          ← Main dashboard page
├── static/
│   ├── style.css       ← All styles (dark theme, responsive)
│   └── app.js          ← WebSocket client, rendering, API calls
└── README.md
```
