# AI Smart Traffic Signal System — Backend

## Setup & Run

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the server
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/intersections` | List all intersections |
| GET | `/api/intersections/{id}` | Get one intersection state |
| GET | `/api/signals` | All current signal states |
| POST | `/api/intersections/{id}/mode` | Set mode (AI/MANUAL/EMERGENCY) |
| POST | `/api/intersections/{id}/signal` | Override signal direction |
| POST | `/api/analyze-frame` | Upload frame for CV analysis |
| POST | `/api/detect-emergency` | Trigger emergency detection |
| GET | `/api/emergency-alerts` | Emergency alert history |
| GET | `/api/analytics/summary` | System analytics |
| GET | `/api/history` | Traffic history snapshots |
| WS | `/ws/traffic` | Real-time WebSocket feed |

## Swagger Docs
Visit `http://localhost:8000/docs` for interactive API documentation.

## Architecture

```
main.py
  ├── Signal State (in-memory dict per intersection)
  ├── Traffic Engine (async background task, 5s interval)
  │     ├── compute_optimal_green_time()   ← ML signal optimization
  │     ├── detect_emergency_vehicle()     ← CV emergency detection
  │     └── analyze_frame()               ← OpenCV vehicle counting
  ├── REST API (FastAPI)
  └── WebSocket (real-time broadcast)
```

## Production Extension Points
- Replace `analyze_frame()` with YOLOv8 inference on actual camera frames
- Replace `detect_emergency_vehicle()` with siren audio + visual detection model
- Connect Redis for state persistence across instances
- Add PostgreSQL for long-term traffic analytics
- Add RTSP camera stream ingestion with OpenCV VideoCapture
