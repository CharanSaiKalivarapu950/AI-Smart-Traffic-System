"""
AI-Driven Smart Traffic Signal System
Backend API - FastAPI
Author: Kalivarapu Charan Sai
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
import json
import random
import time
import base64
import numpy as np
from datetime import datetime
from typing import List, Dict, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="AI Smart Traffic Signal System",
    description="Computer Vision-based real-time traffic monitoring and signal optimization",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── In-Memory State ───────────────────────────────────────────────────────────

INTERSECTIONS = {
    "INT_001": {"name": "MG Road & Tank Bund", "location": {"lat": 17.4126, "lng": 78.4772}},
    "INT_002": {"name": "Hitech City Flyover", "location": {"lat": 17.4435, "lng": 78.3772}},
    "INT_003": {"name": "Banjara Hills Rd 12", "location": {"lat": 17.4219, "lng": 78.4487}},
    "INT_004": {"name": "PVNR Expressway Gate", "location": {"lat": 17.3850, "lng": 78.4867}},
}

DIRECTIONS = ["North", "South", "East", "West"]

signal_state: Dict = {}
traffic_history: List[Dict] = []
emergency_alerts: List[Dict] = []
active_ws_clients: List[WebSocket] = []

def initialize_signals():
    for int_id, info in INTERSECTIONS.items():
        signal_state[int_id] = {
            "intersection_id": int_id,
            "name": info["name"],
            "location": info["location"],
            "current_phase": "North",
            "phase_timer": 30,
            "mode": "AI",   # AI | MANUAL | EMERGENCY
            "emergency_active": False,
            "emergency_direction": None,
            "lanes": {
                d: {
                    "vehicle_count": random.randint(5, 40),
                    "density": round(random.uniform(0.1, 0.9), 2),
                    "wait_time": random.randint(10, 90),
                    "signal": "RED",
                    "green_duration": 30,
                    "queue_length": random.randint(2, 20),
                }
                for d in DIRECTIONS
            },
            "last_updated": datetime.now().isoformat()
        }
    # Set initial green for North
    for int_id in signal_state:
        signal_state[int_id]["lanes"]["North"]["signal"] = "GREEN"

initialize_signals()


# ─── Core ML Logic (Simulated) ─────────────────────────────────────────────────

def compute_optimal_green_time(vehicle_count: int, density: float, wait_time: int) -> int:
    """
    Simulates ML-based green time allocation.
    Uses weighted scoring: density (50%) + wait (30%) + count (20%)
    Returns green duration in seconds (15–90s).
    """
    base = 15
    density_weight = density * 40
    wait_weight = min(wait_time / 90, 1.0) * 25
    count_weight = min(vehicle_count / 50, 1.0) * 15
    score = base + density_weight + wait_weight + count_weight
    return int(min(max(score, 15), 90))


def detect_emergency_vehicle(frame_data: Optional[bytes] = None) -> Dict:
    """
    Simulates emergency vehicle detection via CV.
    In production: YOLO/SSD model inference on frame.
    """
    detected = random.random() < 0.08   # 8% chance per call
    direction = random.choice(DIRECTIONS) if detected else None
    confidence = round(random.uniform(0.85, 0.99), 2) if detected else 0.0
    vehicle_type = random.choice(["Ambulance", "Fire Truck", "Police"]) if detected else None
    return {
        "detected": detected,
        "direction": direction,
        "confidence": confidence,
        "vehicle_type": vehicle_type,
        "timestamp": datetime.now().isoformat()
    }


def analyze_frame(frame_b64: Optional[str] = None) -> Dict:
    """
    Simulates OpenCV + YOLO vehicle detection on a video frame.
    Returns per-direction counts and densities.
    """
    results = {}
    for d in DIRECTIONS:
        count = random.randint(0, 50)
        density = round(count / 50, 2)
        results[d] = {
            "vehicle_count": count,
            "density": density,
            "vehicle_types": {
                "car": int(count * 0.6),
                "bus": int(count * 0.1),
                "truck": int(count * 0.1),
                "motorcycle": int(count * 0.2),
            }
        }
    return results


def update_traffic_state():
    """Update all intersections with simulated sensor/CV data."""
    for int_id, state in signal_state.items():
        if state["mode"] == "EMERGENCY":
            continue   # Emergency logic handled separately

        # Simulate sensor readings
        for d in DIRECTIONS:
            lane = state["lanes"][d]
            delta = random.randint(-5, 8)
            lane["vehicle_count"] = max(0, min(60, lane["vehicle_count"] + delta))
            lane["density"] = round(lane["vehicle_count"] / 60, 2)

            if lane["signal"] == "RED":
                lane["wait_time"] = min(lane["wait_time"] + 5, 180)
            else:
                lane["wait_time"] = max(0, lane["wait_time"] - 10)

            lane["queue_length"] = max(0, int(lane["vehicle_count"] * 0.6))
            lane["green_duration"] = compute_optimal_green_time(
                lane["vehicle_count"], lane["density"], lane["wait_time"]
            )

        # Rotate phase
        phases = DIRECTIONS
        current_idx = phases.index(state["current_phase"])
        green_dir = state["current_phase"]
        state["phase_timer"] -= 5
        if state["phase_timer"] <= 0:
            next_idx = (current_idx + 1) % len(phases)
            state["current_phase"] = phases[next_idx]
            green_dir = state["current_phase"]
            state["phase_timer"] = state["lanes"][green_dir]["green_duration"]

        # Update signals
        for d in DIRECTIONS:
            state["lanes"][d]["signal"] = "GREEN" if d == green_dir else "RED"

        state["last_updated"] = datetime.now().isoformat()

    # Log snapshot
    snapshot = {
        "timestamp": datetime.now().isoformat(),
        "intersections": {
            k: {
                "mode": v["mode"],
                "phase": v["current_phase"],
                "avg_density": round(
                    sum(v["lanes"][d]["density"] for d in DIRECTIONS) / 4, 2
                ),
                "avg_wait": round(
                    sum(v["lanes"][d]["wait_time"] for d in DIRECTIONS) / 4, 1
                ),
            }
            for k, v in signal_state.items()
        }
    }
    traffic_history.append(snapshot)
    if len(traffic_history) > 200:
        traffic_history.pop(0)


# ─── WebSocket Broadcast ───────────────────────────────────────────────────────

async def broadcast(message: dict):
    disconnected = []
    for ws in active_ws_clients:
        try:
            await ws.send_json(message)
        except Exception:
            disconnected.append(ws)
    for ws in disconnected:
        active_ws_clients.remove(ws)


async def traffic_engine():
    """Background loop: update state every 5 seconds and broadcast."""
    while True:
        await asyncio.sleep(5)
        update_traffic_state()
        await broadcast({
            "type": "state_update",
            "data": signal_state,
            "timestamp": datetime.now().isoformat()
        })
        # Random emergency check
        for int_id in signal_state:
            ev = detect_emergency_vehicle()
            if ev["detected"] and not signal_state[int_id]["emergency_active"]:
                signal_state[int_id]["mode"] = "EMERGENCY"
                signal_state[int_id]["emergency_active"] = True
                signal_state[int_id]["emergency_direction"] = ev["direction"]
                # Give green to emergency direction
                for d in DIRECTIONS:
                    signal_state[int_id]["lanes"][d]["signal"] = (
                        "GREEN" if d == ev["direction"] else "RED"
                    )
                alert = {
                    "id": f"EMG_{int(time.time())}",
                    "intersection_id": int_id,
                    "intersection_name": signal_state[int_id]["name"],
                    **ev
                }
                emergency_alerts.append(alert)
                if len(emergency_alerts) > 50:
                    emergency_alerts.pop(0)
                await broadcast({"type": "emergency_alert", "data": alert})
                # Auto-clear after 30s (simulated)
                asyncio.create_task(clear_emergency(int_id, delay=30))


async def clear_emergency(int_id: str, delay: int = 30):
    await asyncio.sleep(delay)
    if int_id in signal_state:
        signal_state[int_id]["mode"] = "AI"
        signal_state[int_id]["emergency_active"] = False
        signal_state[int_id]["emergency_direction"] = None
        await broadcast({
            "type": "emergency_cleared",
            "data": {"intersection_id": int_id, "timestamp": datetime.now().isoformat()}
        })


@app.on_event("startup")
async def startup_event():
    asyncio.create_task(traffic_engine())
    logger.info("Traffic engine started.")


# ─── REST Endpoints ────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"message": "AI Smart Traffic Signal System API", "version": "1.0.0"}


@app.get("/api/intersections")
def get_intersections():
    """List all monitored intersections."""
    return {"intersections": list(signal_state.values())}


@app.get("/api/intersections/{int_id}")
def get_intersection(int_id: str):
    if int_id not in signal_state:
        raise HTTPException(status_code=404, detail="Intersection not found")
    return signal_state[int_id]


@app.get("/api/signals")
def get_all_signals():
    """Get current signal states for all intersections."""
    return {"data": signal_state, "timestamp": datetime.now().isoformat()}


@app.post("/api/intersections/{int_id}/mode")
def set_mode(int_id: str, payload: dict):
    """Switch intersection mode: AI | MANUAL | EMERGENCY"""
    if int_id not in signal_state:
        raise HTTPException(status_code=404, detail="Intersection not found")
    mode = payload.get("mode", "AI").upper()
    if mode not in ["AI", "MANUAL", "EMERGENCY"]:
        raise HTTPException(status_code=400, detail="Invalid mode")
    signal_state[int_id]["mode"] = mode
    return {"message": f"Mode set to {mode}", "intersection_id": int_id}


@app.post("/api/intersections/{int_id}/signal")
def override_signal(int_id: str, payload: dict):
    """Manually override signal for a direction (MANUAL mode only)."""
    if int_id not in signal_state:
        raise HTTPException(status_code=404, detail="Intersection not found")
    direction = payload.get("direction")
    signal = payload.get("signal", "GREEN").upper()
    if direction not in DIRECTIONS:
        raise HTTPException(status_code=400, detail="Invalid direction")
    if signal not in ["GREEN", "RED", "YELLOW"]:
        raise HTTPException(status_code=400, detail="Invalid signal")
    signal_state[int_id]["lanes"][direction]["signal"] = signal
    return {"message": "Signal updated", "direction": direction, "signal": signal}


@app.post("/api/analyze-frame")
async def analyze_video_frame(file: UploadFile = File(None)):
    """
    Analyze a video frame for vehicle detection.
    In production: runs YOLO inference on the uploaded frame.
    """
    frame_data = await file.read() if file else None
    result = analyze_frame(frame_data)
    return {
        "status": "analyzed",
        "detections": result,
        "model": "YOLOv8-traffic",
        "inference_time_ms": round(random.uniform(18, 45), 1),
        "timestamp": datetime.now().isoformat()
    }


@app.post("/api/detect-emergency")
def detect_emergency(payload: dict = {}):
    """
    Trigger emergency vehicle detection check.
    Returns detection result and updates signal if detected.
    """
    int_id = payload.get("intersection_id")
    result = detect_emergency_vehicle()
    if result["detected"] and int_id and int_id in signal_state:
        signal_state[int_id]["mode"] = "EMERGENCY"
        signal_state[int_id]["emergency_active"] = True
        signal_state[int_id]["emergency_direction"] = result["direction"]
        for d in DIRECTIONS:
            signal_state[int_id]["lanes"][d]["signal"] = (
                "GREEN" if d == result["direction"] else "RED"
            )
    return result


@app.get("/api/emergency-alerts")
def get_emergency_alerts():
    return {"alerts": list(reversed(emergency_alerts))}


@app.get("/api/history")
def get_history(limit: int = 50):
    return {"history": traffic_history[-limit:]}


@app.get("/api/analytics/summary")
def get_analytics():
    """System-wide analytics summary."""
    total_vehicles = sum(
        signal_state[i]["lanes"][d]["vehicle_count"]
        for i in signal_state for d in DIRECTIONS
    )
    avg_wait = round(
        sum(signal_state[i]["lanes"][d]["wait_time"] for i in signal_state for d in DIRECTIONS)
        / (len(signal_state) * 4), 1
    )
    avg_density = round(
        sum(signal_state[i]["lanes"][d]["density"] for i in signal_state for d in DIRECTIONS)
        / (len(signal_state) * 4), 2
    )
    congested = sum(
        1 for i in signal_state for d in DIRECTIONS
        if signal_state[i]["lanes"][d]["density"] > 0.7
    )
    return {
        "total_vehicles_detected": total_vehicles,
        "avg_wait_time_seconds": avg_wait,
        "avg_density": avg_density,
        "congested_lanes": congested,
        "active_intersections": len(signal_state),
        "emergency_active": sum(1 for i in signal_state if signal_state[i]["emergency_active"]),
        "ai_controlled": sum(1 for i in signal_state if signal_state[i]["mode"] == "AI"),
        "timestamp": datetime.now().isoformat()
    }


# ─── WebSocket ─────────────────────────────────────────────────────────────────

@app.websocket("/ws/traffic")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_ws_clients.append(websocket)
    logger.info(f"WebSocket connected. Total clients: {len(active_ws_clients)}")
    try:
        # Send initial state
        await websocket.send_json({
            "type": "initial_state",
            "data": signal_state,
            "timestamp": datetime.now().isoformat()
        })
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        active_ws_clients.remove(websocket)
        logger.info("WebSocket disconnected.")
